package com.example.fintechapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class UserProfile extends AppCompatActivity {
    TextView name, phoneNumber, email, account_no, amt;
    Button add_amt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        name = findViewById(R.id.username);
        phoneNumber = findViewById(R.id.userphonenumber);
        email = findViewById(R.id.email);
        account_no = findViewById(R.id.account_no);
        amt = findViewById(R.id.amt);
        add_amt = findViewById(R.id.add_amt);

        Intent i=getIntent();
        User s=(User)i.getSerializableExtra("std");

        name.setText(s.getName());
        phoneNumber.setText(s.getPhoneNo().toString());
        email.setText(s.getEmail().toString());
        account_no.setText(s.getAccountNo().toString());
        amt.setText(s.getBalance().toString());
    }
}