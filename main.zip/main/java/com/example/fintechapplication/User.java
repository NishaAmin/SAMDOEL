package com.example.fintechapplication;

import java.io.Serializable;

public class User implements Serializable {
    String name,email;
    Integer accno,phone;
    Float balance;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public Integer getPhoneNo() {
        return phone;
    }
    public void setPhoneNo(Integer phone) {
        this.phone=phone;
    }
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    public Integer getAccountNo() {
        return accno;
    }

    public void setAccountNo(Integer accountNo) {
        this.accno = accountNo;
    }

    public Float getBalance() {
        return balance;
    }

    public void setBalance(Float balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", phone='" + phone  +
                ", email='" + email  +
                ", accno=" + accno +
                ", balance=" + balance +
                '}';
    }



}
