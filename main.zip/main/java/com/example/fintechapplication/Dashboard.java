package com.example.fintechapplication;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Dashboard extends AppCompatActivity {

    TextView tvPhoneNumber,tvName,tvAcc,tvBal,tvEmail;
    Button btnSignOut;
    String[][] users = {{ "Nisha","2347676856", "$2345","+923182801481","nishaamin@gmail.com" },
            {"Amin","2344676856", "$2745","+923312605688","amin@gmail.com" },
            { "Zain", "9876543267","$6538","+923127271954","zainimalik@gmail.com" },
            { "Urwa", "6258763865","$1234", "+923334876453","urwa@gmail.com" }};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        findViews();
        setPhoneNumber();


        btnSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(Dashboard.this,MainActivity.class));
                finish();
            }
        });
    }

    private void findViews() {
        tvPhoneNumber=findViewById(R.id.tv_phone_number);
        tvName=findViewById(R.id.tv_name);
        btnSignOut=findViewById(R.id.btn_sign_out);
        tvAcc=findViewById(R.id.tvacc);
        tvBal=findViewById(R.id.tvbalance);
        tvEmail=findViewById(R.id.tvEmail);

    }

    private void setPhoneNumber(){
        FirebaseUser user= FirebaseAuth.getInstance().getCurrentUser();
        try {
            tvPhoneNumber.setText(user.getPhoneNumber());
            Intent i=getIntent();
            String sData=i.getStringExtra("data");
            tvName.setText(sData);

        }catch (Exception e){
            Toast.makeText(this,"Phone number not found",Toast.LENGTH_SHORT).show();
        }

        for (String[] strings : users) {
            if (tvName.toString()==strings[0]) {
                for (int j = 0; j < strings.length; j++) {
                    tvAcc.setText(strings[1]);
                    tvBal.setText(strings[2]);
                }
            }

        }
    }
    public void OnItemMenuProfileClicked(View view) {
        Intent intent=new Intent(Dashboard.this,UserProfile.class);
        User usr = new User();
        usr.setName(tvName.getText().toString());
        usr.setPhoneNo(Integer.parseInt(tvPhoneNumber.getText().toString()));
        usr.setEmail(tvEmail.getText().toString());
        usr.setAccountNo(Integer.parseInt(tvAcc.getText().toString()));
        usr.setBalance(Float.parseFloat(tvBal.getText().toString()));
        intent.putExtra("usr", usr);
        startActivity(intent);
    }



}

